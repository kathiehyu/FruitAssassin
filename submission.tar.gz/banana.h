/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=15x15 banana banana.png 
 * Time-stamp: Sunday 04/02/2023, 20:08:21
 * 
 * Image Information
 * -----------------
 * banana.png 15@15
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef BANANA_H
#define BANANA_H

extern const unsigned short banana[225];
#define BANANA_SIZE 450
#define BANANA_LENGTH 225
#define BANANA_WIDTH 15
#define BANANA_HEIGHT 15

#endif

