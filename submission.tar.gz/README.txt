Welcome to fruit assassin!
Your goal is to cut fruit, but do not cut the onions or you will cry!
Choose your time limit with the UP, DOWN, and START button, to continue to the game.
Control your cutting knives, located on the left and right sides of the screen, using the up and down buttons to align them with the fruit. To cut, use the LEFT or RIGHT buttons.
You can exit to the main screen at any time by pressing SELECT, and you can exit to the game over screen at any time by cutting an onion.
You have one minute to cut as many fruit as you can. Good luck!