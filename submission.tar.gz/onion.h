/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=15x15 onion onion.png 
 * Time-stamp: Sunday 04/02/2023, 22:00:29
 * 
 * Image Information
 * -----------------
 * onion.png 15@15
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef ONION_H
#define ONION_H

extern const unsigned short onion[225];
#define ONION_SIZE 450
#define ONION_LENGTH 225
#define ONION_WIDTH 15
#define ONION_HEIGHT 15

#endif

