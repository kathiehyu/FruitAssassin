/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=15x15 cherry cherry.png 
 * Time-stamp: Sunday 04/02/2023, 20:08:13
 * 
 * Image Information
 * -----------------
 * cherry.png 15@15
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef CHERRY_H
#define CHERRY_H

extern const unsigned short cherry[225];
#define CHERRY_SIZE 450
#define CHERRY_LENGTH 225
#define CHERRY_WIDTH 15
#define CHERRY_HEIGHT 15

#endif

