/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=15x15 mango mango.png 
 * Time-stamp: Tuesday 04/04/2023, 05:46:47
 * 
 * Image Information
 * -----------------
 * mango.png 15@15
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef MANGO_H
#define MANGO_H

extern const unsigned short mango[225];
#define MANGO_SIZE 450
#define MANGO_LENGTH 225
#define MANGO_WIDTH 15
#define MANGO_HEIGHT 15

#endif

