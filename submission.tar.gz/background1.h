/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=240x160 background1 background1.png 
 * Time-stamp: Sunday 04/02/2023, 02:22:55
 * 
 * Image Information
 * -----------------
 * background1.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef BACKGROUND1_H
#define BACKGROUND1_H

extern const unsigned short background1[38400];
#define BACKGROUND1_SIZE 76800
#define BACKGROUND1_LENGTH 38400
#define BACKGROUND1_WIDTH 240
#define BACKGROUND1_HEIGHT 160

#endif

